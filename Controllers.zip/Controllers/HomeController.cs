using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Hotel_Management_System.Data;
using Hotel_Management_System.Models;
using Hotel_Management_System.Models.ViewModels;

namespace Hotel_Management_System.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // 👑 ১. যদি লগইন করা ইউজার Admin হয়, তবে Admin Dashboard এর ডাটা লোড হবে
            if (User.IsInRole("Admin"))
            {
                var today = DateTime.Today;

                decimal totalRevenue = await _context.Bookings
                    .Where(b => b.Status == "Confirmed")
                    .SumAsync(b => b.TotalPrice);

                int totalBookings = await _context.Bookings.CountAsync();

                int todayCheckIns = await _context.Bookings
                    .CountAsync(b => b.Status == "Confirmed" && b.CheckInDate.Date == today);

                int totalRooms = await _context.Rooms.CountAsync();
                int bookedRoomsCount = await _context.Bookings
                    .Where(b => b.Status == "Confirmed" && b.CheckOutDate.Date >= today)
                    .Select(b => b.RoomId)
                    .Distinct()
                    .CountAsync();

                int availableRoomsCount = totalRooms - bookedRoomsCount;

                double occupancyRate = totalRooms > 0
                    ? Math.Round(((double)bookedRoomsCount / totalRooms) * 100, 1)
                    : 0;

                var chartLabels = new List<string>();
                var chartData = new List<decimal>();

                for (int i = 6; i >= 0; i--)
                {
                    var date = today.AddDays(-i);
                    chartLabels.Add(date.ToString("dd MMM"));

                    decimal dayIncome = await _context.Bookings
                        .Where(b => b.Status == "Confirmed" && b.BookingDate.Date == date)
                        .SumAsync(b => b.TotalPrice);

                    chartData.Add(dayIncome);
                }

                var recentBookings = await _context.Bookings
                    .Include(b => b.Guest)
                    .Include(b => b.Room)
                    .OrderByDescending(b => b.BookingDate)
                    .Take(5)
                    .ToListAsync();

                var dashboardModel = new AdminDashboardViewModel
                {
                    TotalRevenue = totalRevenue,
                    TotalBookings = totalBookings,
                    TodayCheckIns = todayCheckIns,
                    AvailableRoomsCount = availableRoomsCount,
                    OccupancyRate = occupancyRate,
                    ChartLabels = chartLabels,
                    ChartData = chartData,
                    RecentBookings = recentBookings
                };

                // 👈 অ্যাডমিনের জন্য সুনির্দিষ্টভাবে AdminIndex.cshtml ভিউ রিটার্ন করা হলো
                return View("AdminIndex", dashboardModel);
            }

            // 🏨 ২. সাধারণ ইউজার বা Guest হলে হোম পেজে ফিচারড রুমসমূহ দেখাবে
            var featuredRooms = await _context.Rooms
                .Include(r => r.RoomType)
                .Where(r => r.IsAvailable)
                .Take(3)
                .ToListAsync();

            // 👈 গেস্টের জন্য সুনির্দিষ্টভাবে Index.cshtml ভিউ রিটার্ন করা হলো
            return View("Index", featuredRooms);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}