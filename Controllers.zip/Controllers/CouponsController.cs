﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Hotel_Management_System.Data;
using Hotel_Management_System.Models;

namespace Hotel_Management_System.Controllers
{
    public class CouponsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CouponsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Coupons (With Usage Analytics)
        public async Task<IActionResult> Index()
        {
            var coupons = await _context.Coupons.ToListAsync();
            var bookings = await _context.Bookings.Where(b => !string.IsNullOrEmpty(b.AppliedCoupon)).ToListAsync();

            // প্রতিটি কুপনের জন্য ব্যবহার সংখ্যা এবং মোট দেওয়া ডিসকাউন্ট হিসাব করা
            var couponStats = coupons.Select(c => new CouponAnalyticsViewModel
            {
                Coupon = c,
                TotalUsed = bookings.Count(b => b.AppliedCoupon == c.Code),
                TotalDiscountAmount = bookings.Where(b => b.AppliedCoupon == c.Code).Sum(b => b.DiscountAmount)
            }).ToList();

            return View(couponStats);
        }

        // GET: Coupons/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Coupons/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Coupon coupon)
        {
            if (ModelState.IsValid)
            {
                _context.Add(coupon);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(coupon);
        }

        // POST: Coupons/ToggleStatus/5 (কুপন একটিভ/ডিএকটিভ করার জন্য)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleStatus(int id)
        {
            var coupon = await _context.Coupons.FindAsync(id);
            if (coupon == null)
            {
                return NotFound();
            }

            coupon.IsActive = !coupon.IsActive;
            _context.Update(coupon);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }

    // কুপন এনালিটিক্সের জন্য সাপোর্টিং ViewModel
    public class CouponAnalyticsViewModel
    {
        public Coupon Coupon { get; set; } = new Coupon();
        public int TotalUsed { get; set; }
        public decimal TotalDiscountAmount { get; set; }
    }
}