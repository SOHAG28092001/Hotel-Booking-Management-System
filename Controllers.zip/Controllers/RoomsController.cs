﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Hotel_Management_System.Data;
using Hotel_Management_System.Models;

namespace Hotel_Management_System.Controllers
{
    public class RoomsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public RoomsController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        // GET: Rooms
        public async Task<IActionResult> Index(DateTime? checkIn, DateTime? checkOut, int? roomTypeId)
        {
            await SyncRoomAvailabilityAsync();

            ViewData["RoomTypeId"] = new SelectList(_context.RoomTypes, "Id", "Name");

            var rooms = _context.Rooms.Include(r => r.RoomType).AsQueryable();

            if (roomTypeId.HasValue)
            {
                rooms = rooms.Where(r => r.RoomTypeId == roomTypeId.Value);
            }

            return View(await rooms.OrderBy(r => r.RoomNumber).ToListAsync());
        }

        // GET: Rooms/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var room = await _context.Rooms
                .Include(r => r.RoomType)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (room == null) return NotFound();

            return View(room);
        }

        // GET: Rooms/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            ViewData["RoomTypeId"] = new SelectList(_context.RoomTypes, "Id", "Name");
            return View();
        }

        // POST: Rooms/Create
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Room room, IFormFile? imageFile)
        {
            ModelState.Remove("RoomType");
            ModelState.Remove("ImageUrl");

            if (ModelState.IsValid)
            {
                if (imageFile != null && imageFile.Length > 0)
                {
                    string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images/rooms");
                    if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);

                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + imageFile.FileName;
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await imageFile.CopyToAsync(fileStream);
                    }

                    room.ImageUrl = "/images/rooms/" + uniqueFileName;
                }
                else if (string.IsNullOrEmpty(room.ImageUrl))
                {
                    room.ImageUrl = "https://via.placeholder.com/300x200?text=Room+Image";
                }

                _context.Add(room);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["RoomTypeId"] = new SelectList(_context.RoomTypes, "Id", "Name", room.RoomTypeId);
            return View(room);
        }

        // GET: Rooms/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var room = await _context.Rooms.FindAsync(id);
            if (room == null) return NotFound();

            ViewData["RoomTypeId"] = new SelectList(_context.RoomTypes, "Id", "Name", room.RoomTypeId);
            return View(room);
        }

        // POST: Rooms/Edit/5
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Room room, IFormFile? imageFile)
        {
            if (id != room.Id) return NotFound();

            ModelState.Remove("RoomType");
            ModelState.Remove("ImageUrl");

            if (ModelState.IsValid)
            {
                try
                {
                    var existingRoom = await _context.Rooms.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id);
                    if (existingRoom == null) return NotFound();

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images/rooms");
                        if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);

                        string uniqueFileName = Guid.NewGuid().ToString() + "_" + imageFile.FileName;
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }

                        room.ImageUrl = "/images/rooms/" + uniqueFileName;
                    }
                    else
                    {
                        room.ImageUrl = existingRoom.ImageUrl;
                    }

                    // স্ট্যাটাস এবং এভেইলাবিলিটি ঠিক রেখে ডাটাবেজ আপডেট করা
                    _context.Update(room);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RoomExists(room.Id)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["RoomTypeId"] = new SelectList(_context.RoomTypes, "Id", "Name", room.RoomTypeId);
            return View(room);
        }

        // POST: Rooms/UpdateStatus
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            var room = await _context.Rooms.FindAsync(id);
            if (room == null) return NotFound();

            room.Status = status;

            // যদি স্ট্যাটাস Available করা হয়, তবে IsAvailable ট্রিগারও true করে দেওয়া যেতে পারে
            if (status == "Available")
            {
                room.IsAvailable = true;
            }
            else if (status == "Occupied")
            {
                room.IsAvailable = false;
            }

            _context.Update(room);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = $"Room {room.RoomNumber} status updated to {status} successfully!";
            return RedirectToAction(nameof(Index));
        }

        private async Task SyncRoomAvailabilityAsync()
        {
            var today = DateTime.Today;

            var expiredBookings = await _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.Status == "Confirmed" && b.CheckOutDate.Date < today && b.Room != null)
                .ToListAsync();

            foreach (var booking in expiredBookings)
            {
                booking.Status = "Completed";
                if (booking.Room != null)
                {
                    booking.Room.IsAvailable = true;
                    booking.Room.Status = "Available"; // এক্সপায়ার্ড বুকিং হলে রুম আবার Available হয়ে যাবে
                    _context.Update(booking.Room);
                }
                _context.Update(booking);
            }

            var activeConfirmedRoomIds = await _context.Bookings
                .Where(b => b.Status == "Confirmed" && b.CheckOutDate.Date >= today)
                .Select(b => b.RoomId)
                .Distinct()
                .ToListAsync();

            var roomsToFree = await _context.Rooms
                .Where(r => !activeConfirmedRoomIds.Contains(r.Id) && !r.IsAvailable && r.Status == "Occupied")
                .ToListAsync();

            foreach (var room in roomsToFree)
            {
                room.IsAvailable = true;
                room.Status = "Available";
                _context.Update(room);
            }

            var roomsToBlock = await _context.Rooms
                .Where(r => activeConfirmedRoomIds.Contains(r.Id) && r.IsAvailable)
                .ToListAsync();

            foreach (var room in roomsToBlock)
            {
                room.IsAvailable = false;
                room.Status = "Occupied";
                _context.Update(room);
            }

            await _context.SaveChangesAsync();
        }

        private bool RoomExists(int id)
        {
            return _context.Rooms.Any(e => e.Id == id);
        }
    }
}