﻿using System;
using System.Collections.Generic;
using Hotel_Management_System.Models;

namespace Hotel_Management_System.Models.ViewModels
{
    public class AdminDashboardViewModel
    {
        // KPI Card Data
        public decimal TotalRevenue { get; set; }
        public int TotalBookings { get; set; }
        public int TodayCheckIns { get; set; }
        public int AvailableRoomsCount { get; set; }
        public double OccupancyRate { get; set; }

        // Chart Data (গত ৭ দিনের তারিখ ও ইনকাম)
        public List<string> ChartLabels { get; set; } = new List<string>();
        public List<decimal> ChartData { get; set; } = new List<decimal>();

        // Recent Bookings List
        public List<Booking> RecentBookings { get; set; } = new List<Booking>();
    }
}