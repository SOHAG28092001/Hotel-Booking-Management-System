﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Hotel_Management_System.Data;
using Microsoft.AspNetCore.Authorization;

namespace Hotel_Management_System.Controllers
{
    [Authorize(Roles = "Admin")]
    public class CalendarController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CalendarController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Calendar
        public async Task<IActionResult> Index()
        {
            var rooms = await _context.Rooms
                .Include(r => r.RoomType)
                .OrderBy(r => r.RoomNumber)
                .ToListAsync();

            var bookings = await _context.Bookings
                .Include(b => b.Guest)
                .Where(b => b.Status == "Confirmed" || b.Status == "Pending")
                .ToListAsync();

            ViewBag.Bookings = bookings;

            // যেহেতু ফাইলটি Views/Bookings ফোল্ডারে আছে, তাই পুরো পাথ নির্দিষ্ট করে দেওয়া হলো
            return View("~/Views/Bookings/Calendar.cshtml", rooms);
        }
    }

}