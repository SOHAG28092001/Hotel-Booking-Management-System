﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Hotel_Management_System.Data;
using Hotel_Management_System.Models;

namespace Hotel_Management_System.Controllers
{
    public class GuestsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GuestsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // কাস্টমারদের তালিকা (বুকিং হিস্ট্রি সহ)
        public async Task<IActionResult> Index()
        {
            var guests = await _context.Guests
                .Include(g => g.Bookings)
                .ToListAsync();

            return View(guests);
        }

        // কাস্টমারের বিস্তারিত প্রোফাইল ও সম্পূর্ণ বুকিং হিস্ট্রি
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var guest = await _context.Guests
                .Include(g => g.Bookings)
                    .ThenInclude(b => b.Room)
                        .ThenInclude(r => r.RoomType)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (guest == null)
            {
                return NotFound();
            }

            return View(guest);
        }

        // নতুন কাস্টমার এন্ট্রির ফর্ম
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Guest guest)
        {
            // Bookings লিস্টের জন্য ModelState Error যেন না দেয়
            ModelState.Remove("Bookings");

            if (ModelState.IsValid)
            {
                _context.Add(guest);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(guest);
        }

        // কাস্টমার তথ্য এডিট ফর্ম (GET)
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var guest = await _context.Guests.FindAsync(id);
            if (guest == null)
            {
                return NotFound();
            }
            return View(guest);
        }

        // কাস্টমার তথ্য আপডেট (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Guest guest)
        {
            if (id != guest.Id)
            {
                return NotFound();
            }

            // Bookings লিস্ট এডিট ফর্মে থাকে না, তাই ModelState এরর ইগনোর করতে
            ModelState.Remove("Bookings");

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(guest);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GuestExists(guest.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(guest);
        }

        // GET: Guests/MyProfile (লগইন করা ইউজারের নিজস্ব প্রোফাইল দেখার জন্য)
        [Authorize]
        public async Task<IActionResult> MyProfile()
        {
            var userEmail = User.Identity?.Name;
            var guest = await _context.Guests.FirstOrDefaultAsync(g => g.Email == userEmail);

            if (guest == null)
            {
                // যদি গেস্ট প্রোফাইল না থাকে তবে অটো তৈরি করে নিতে পারেন
                guest = new Guest { Email = userEmail, FullName = User.Identity?.Name?.Split('@')[0] };
                _context.Guests.Add(guest);
                await _context.SaveChangesAsync();
            }
            return View(guest);
        }

        // POST: Guests/MyProfile (লগইন করা ইউজারের নিজস্ব প্রোফাইল আপডেট করার জন্য)
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MyProfile(int id, [Bind("Id,FullName,Email,PhoneNumber,Address")] Guest guest)
        {
            if (id != guest.Id) return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(guest);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Profile updated successfully!";
                return RedirectToAction(nameof(MyProfile));
            }
            return View(guest);
        }

        private bool GuestExists(int id)
        {
            return _context.Guests.Any(e => e.Id == id);
        }
    }
}