﻿using Hotel_Management_System.Data;
using Hotel_Management_System.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Hotel_Management_System.Controllers
{
    [Authorize(Roles = "Admin")]
    public class RoomTypesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RoomTypesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ১. সব রুম ক্যাটাগরির তালিকা দেখা
        public async Task<IActionResult> Index()
        {
            var roomTypes = await _context.RoomTypes.ToListAsync();
            return View(roomTypes);
        }

        // ২. নতুন ক্যাটাগরি তৈরির ফর্ম
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RoomType roomType)
        {
            if (ModelState.IsValid)
            {
                _context.Add(roomType);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(roomType);
        }

        // ৩. ক্যাটাগরি এডিট করার ফর্ম
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var roomType = await _context.RoomTypes.FindAsync(id);
            if (roomType == null) return NotFound();

            return View(roomType);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, RoomType roomType)
        {
            if (id != roomType.Id) return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(roomType);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(roomType);
        }
        // GET: RoomTypes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var roomType = await _context.RoomTypes
                .FirstOrDefaultAsync(m => m.Id == id);

            if (roomType == null)
            {
                return NotFound();
            }

            return View(roomType);
        }

        // ৪. ক্যাটাগরি ডিলিট করা
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var roomType = await _context.RoomTypes.FirstOrDefaultAsync(m => m.Id == id);
            if (roomType == null) return NotFound();

            return View(roomType);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var roomType = await _context.RoomTypes.FindAsync(id);
            if (roomType != null)
            {
                _context.RoomTypes.Remove(roomType);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}