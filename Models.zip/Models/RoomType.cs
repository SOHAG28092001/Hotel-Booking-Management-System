﻿using System.ComponentModel.DataAnnotations;

namespace Hotel_Management_System.Models
{
    public class RoomType
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public string? Description { get; set; }

        [Required]
        public decimal BasePrice { get; set; }
    }
}