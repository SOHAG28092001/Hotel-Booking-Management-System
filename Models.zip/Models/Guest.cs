﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Hotel_Management_System.Models
{
    public class Guest
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; } = string.Empty;

        public string Address { get; set; } = string.Empty;

        // Guest এর সাথে Bookings এর Navigation Property (1-to-Many Relationship)
        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}