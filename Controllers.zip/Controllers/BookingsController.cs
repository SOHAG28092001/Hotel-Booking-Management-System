﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Hotel_Management_System.Data;
using Hotel_Management_System.Models;
using Hotel_Management_System.Services;
using System.Diagnostics;

namespace Hotel_Management_System.Controllers
{
    [Authorize]
    public class BookingsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly SmsSender _smsSender;

        public BookingsController(ApplicationDbContext context, SmsSender smsSender)
        {
            _context = context;
            _smsSender = smsSender;
        }

        // GET: Bookings
        public async Task<IActionResult> Index()
        {
            var bookings = _context.Bookings.Include(b => b.Guest).Include(b => b.Room).AsQueryable();

            if (!User.IsInRole("Admin"))
            {
                var userEmail = User.Identity?.Name;
                bookings = bookings.Where(b => b.Guest != null && b.Guest.Email == userEmail);
            }

            return View(await bookings.OrderByDescending(b => b.BookingDate).ToListAsync());
        }

        // GET: Bookings/MyBookings
        public async Task<IActionResult> MyBookings()
        {
            var userEmail = User.Identity?.Name;

            var myBookings = await _context.Bookings
                .Include(b => b.Room)
                .ThenInclude(r => r!.RoomType)
                .Include(b => b.Guest)
                .Where(b => b.Guest != null && b.Guest.Email == userEmail)
                .OrderByDescending(b => b.BookingDate)
                .ToListAsync();

            return View(myBookings);
        }

        // GET: Bookings/Create
        public async Task<IActionResult> Create()
        {
            var today = DateTime.Today;

            var activeBookedRoomIds = await _context.Bookings
                .Where(b => (b.Status == "Confirmed" || b.Status == "Pending") && b.CheckOutDate.Date >= today)
                .Select(b => b.RoomId)
                .ToListAsync();

            var availableRooms = await _context.Rooms
                .Where(r => r.IsAvailable && !activeBookedRoomIds.Contains(r.Id))
                .OrderBy(r => r.RoomNumber)
                .Select(r => new {
                    Id = r.Id,
                    Display = "Room " + r.RoomNumber
                }).ToListAsync();

            ViewData["RoomId"] = new SelectList(availableRooms, "Id", "Display");
            return View();
        }

        // POST: Bookings/Create (পেমেন্টের জন্য পেন্ডিং বুকিং হিসেবে সেভ করা এবং পেমেন্ট পেজে রিডাইরেক্ট করা)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Booking booking, string? promoCode)
        {
            ModelState.Remove("Guest");
            ModelState.Remove("Room");

            if (booking.CheckOutDate <= booking.CheckInDate)
            {
                ModelState.AddModelError("CheckOutDate", "Check-Out date must be after Check-In date.");
            }

            var today = DateTime.Today;

            var isAlreadyBooked = await _context.Bookings.AnyAsync(b =>
                b.RoomId == booking.RoomId &&
                (b.Status == "Confirmed" || b.Status == "Pending") &&
                b.CheckOutDate.Date >= today);

            if (isAlreadyBooked)
            {
                ModelState.AddModelError("", "This room is currently booked for the selected dates.");
            }

            if (ModelState.IsValid)
            {
                var room = await _context.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == booking.RoomId);

                if (room != null && !isAlreadyBooked)
                {
                    var userEmail = User.Identity?.Name ?? "guest@hotel.com";
                    var guest = await _context.Guests.FirstOrDefaultAsync(g => g.Email == userEmail);

                    if (guest == null)
                    {
                        guest = new Guest
                        {
                            FullName = User.Identity?.Name?.Split('@')[0] ?? "Guest User",
                            Email = userEmail,
                            PhoneNumber = "+8801700000000",
                            Address = "Dhaka, Bangladesh"
                        };
                        _context.Guests.Add(guest);
                        await _context.SaveChangesAsync();
                    }

                    booking.GuestId = guest.Id;
                    booking.Status = "Pending";          // বুকিং স্ট্যাটাস প্রথমে Pending থাকবে
                    booking.PaymentStatus = "Pending";   // পেমেন্ট স্ট্যাটাস Pending থাকবে

                    int nights = (booking.CheckOutDate - booking.CheckInDate).Days;
                    if (nights <= 0) nights = 1;

                    decimal basePrice = room.RoomType != null ? room.RoomType.BasePrice : 0;
                    decimal totalPrice = nights * basePrice;
                    decimal discountAmount = 0;

                    if (!string.IsNullOrWhiteSpace(promoCode))
                    {
                        var coupon = await _context.Coupons
                            .FirstOrDefaultAsync(c => c.Code.ToUpper() == promoCode.Trim().ToUpper() && c.IsActive);

                        if (coupon != null)
                        {
                            discountAmount = (totalPrice * coupon.DiscountPercentage) / 100;
                            booking.AppliedCoupon = coupon.Code;
                        }
                    }

                    booking.DiscountAmount = discountAmount;
                    booking.TotalPrice = totalPrice - discountAmount;
                    booking.BookingDate = DateTime.Now;

                    _context.Add(booking);
                    await _context.SaveChangesAsync();

                    // বুকিং সেভ করার পর পেমেন্ট পেজে রিডাইরেক্ট করা হচ্ছে
                    return RedirectToAction("Payment", new { id = booking.Id });
                }
                else
                {
                    ModelState.AddModelError("", "Selected room is no longer available.");
                }
            }

            var activeBookedRoomIds = await _context.Bookings
                .Where(b => (b.Status == "Confirmed" || b.Status == "Pending") && b.CheckOutDate.Date >= today)
                .Select(b => b.RoomId)
                .ToListAsync();

            var availableRooms = await _context.Rooms
                .Where(r => r.IsAvailable && !activeBookedRoomIds.Contains(r.Id))
                .OrderBy(r => r.RoomNumber)
                .Select(r => new {
                    Id = r.Id,
                    Display = "Room " + r.RoomNumber
                }).ToListAsync();

            ViewData["RoomId"] = new SelectList(availableRooms, "Id", "Display", booking.RoomId);
            return View(booking);
        }

        // GET: Bookings/Payment/5 (পেমেন্ট পেজ দেখানোর জন্য)
        public async Task<IActionResult> Payment(int id)
        {
            var booking = await _context.Bookings
                .Include(b => b.Room)
                .ThenInclude(r => r!.RoomType)
                .Include(b => b.Guest)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (booking == null) return NotFound();

            return View(booking);
        }

        // POST: Bookings/ProcessPayment/5 (বিকাশ/নগদ পেমেন্ট প্রসেস করার জন্য)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessPayment(int id, string paymentMethod, string transactionId)
        {
            var booking = await _context.Bookings
                .Include(b => b.Room)
                .Include(b => b.Guest)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (booking == null) return NotFound();

            // পেমেন্ট সফল সিমুলেশন আপডেট
            booking.PaymentMethod = paymentMethod;
            booking.PaymentStatus = "Paid";
            booking.Status = "Confirmed";

            // রুমের স্ট্যাটাস Occupied করা
            if (booking.Room != null)
            {
                booking.Room.IsAvailable = false;
                booking.Room.Status = "Occupied";
                _context.Update(booking.Room);
            }

            _context.Update(booking);
            await _context.SaveChangesAsync();

            // সফল পেমেন্ট ও বুকিং কনফার্মেশনের পর SMS পাঠানো
            if (booking.Guest != null && !string.IsNullOrEmpty(booking.Guest.PhoneNumber))
            {
                try
                {
                    string smsMessage = $"Dear Customer, your payment via {paymentMethod} is successful! Booking for Room {booking.Room?.RoomNumber} is Confirmed. Total: TK {booking.TotalPrice:N2}.";
                    await _smsSender.SendSmsAsync(booking.Guest.PhoneNumber, smsMessage);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"SMS Sending Failed: {ex.Message}");
                }
            }

            TempData["SuccessMessage"] = "Payment successful and booking confirmed!";
            return RedirectToAction("Invoice", new { id = booking.Id });
        }

        // POST: Bookings/Cancel/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id)
        {
            var booking = await _context.Bookings
                .Include(b => b.Room)
                .Include(b => b.Guest)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (booking != null && (booking.Status == "Confirmed" || booking.Status == "Pending"))
            {
                booking.Status = "Cancelled";

                if (booking.Room != null)
                {
                    booking.Room.IsAvailable = true;
                    booking.Room.Status = "Available";
                    _context.Update(booking.Room);
                }

                _context.Update(booking);
                await _context.SaveChangesAsync();

                if (booking.Guest != null && !string.IsNullOrEmpty(booking.Guest.PhoneNumber))
                {
                    try
                    {
                        string cancelSmsMessage = $"Your booking for Room {booking.Room?.RoomNumber} from {booking.CheckInDate:dd MMM} has been Cancelled successfully.";
                        await _smsSender.SendSmsAsync(booking.Guest.PhoneNumber, cancelSmsMessage);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"SMS Cancel Notification Failed: {ex.Message}");
                    }
                }
            }

            return RedirectToAction(nameof(MyBookings));
        }

        // GET: Bookings/Invoice/5
        public async Task<IActionResult> Invoice(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Guest)
                .Include(b => b.Room)
                .ThenInclude(r => r!.RoomType)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (booking == null) return NotFound();

            return View(booking);
        }

        // GET: Bookings/Calendar
        public IActionResult Calendar()
        {
            return View();
        }

        // GET: Bookings/GetCalendarBookings
        [HttpGet]
        public async Task<IActionResult> GetCalendarBookings()
        {
            var bookings = await _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.Status == "Confirmed")
                .Select(b => new
                {
                    title = "Room " + (b.Room != null ? b.Room.RoomNumber : "") + " (Booked)",
                    start = b.CheckInDate.ToString("yyyy-MM-dd"),
                    end = b.CheckOutDate.AddDays(1).ToString("yyyy-MM-dd"),
                    color = "#dc3545"
                })
                .ToListAsync();

            return Json(bookings);
        }
    }
}