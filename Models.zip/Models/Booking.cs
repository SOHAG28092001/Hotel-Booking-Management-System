﻿using System.ComponentModel.DataAnnotations;

namespace Hotel_Management_System.Models
{
    public class Booking
    {
        public int Id { get; set; }

        public int? GuestId { get; set; }
        public Guest? Guest { get; set; }

        [Required(ErrorMessage = "Please select a room")]
        public int RoomId { get; set; }
        public Room? Room { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; }

        [Range(1, 10, ErrorMessage = "Guests must be between 1 and 10")]
        public int NumberOfGuests { get; set; } = 1;

        [Required(ErrorMessage = "NID or Passport number is required for security")]
        [StringLength(50)]
        public string NIDOrPassport { get; set; } = string.Empty;

        [Required]
        public string PaymentMethod { get; set; } = "Pay at Hotel"; // Options: Cash, bKash, Nagad, Card

        public string? SpecialRequest { get; set; }
        public decimal DiscountAmount { get; set; } = 0;
        public string? AppliedCoupon { get; set; }

        public decimal TotalPrice { get; set; }

        public string Status { get; set; } = "Pending"; // Options: Pending, Confirmed, Cancelled, Completed
        public string PaymentStatus { get; set; } = "Pending"; // Options: Pending, Paid

        public DateTime BookingDate { get; set; } = DateTime.Now;
    }
}