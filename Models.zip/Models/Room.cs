﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hotel_Management_System.Models
{
    public class Room
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string RoomNumber { get; set; } // e.g., 101, 102

        [Required]
        public int RoomTypeId { get; set; }

        [ForeignKey("RoomTypeId")]
        public RoomType RoomType { get; set; }

        public bool IsAvailable { get; set; } = true;

        public string ImageUrl { get; set; }
        // Status Options: "Available", "Occupied", "Maintenance", "Cleaning"
        [Required]
        public string Status { get; set; } = "Available";
    }
}