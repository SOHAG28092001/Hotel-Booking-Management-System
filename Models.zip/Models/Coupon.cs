﻿using System.ComponentModel.DataAnnotations;

namespace Hotel_Management_System.Models
{
    public class Coupon
    {
        public int Id { get; set; }

        [Required]
        public string Code { get; set; } = string.Empty; // যেমন: EID2026

        public decimal DiscountPercentage { get; set; } // যেমন: 10% ছাড়ের জন্য 10

        public bool IsActive { get; set; } = true;
    }
}