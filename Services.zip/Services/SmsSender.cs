﻿using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Hotel_Management_System.Services
{
    public class SmsSender
    {
        private readonly IConfiguration _config;

        public SmsSender(IConfiguration config)
        {
            _config = config;
        }

        public async Task SendSmsAsync(string receiverNumber, string message)
        {
            try
            {
                var apiKey = _config["SmsSettings:ApiKey"];

                // Visual Studio Output Window এবং Console উভয় জায়গায় প্রিন্ট করার জন্য
                string logMessage = $"\n========================================\n" +
                                   $"[SMS SENT LOG]\n" +
                                   $"To: {receiverNumber}\n" +
                                   $"Message: {message}\n" +
                                   $"========================================\n";

                Debug.WriteLine(logMessage);
                Console.WriteLine(logMessage);

                // গ্রিনওয়েব API দিয়ে সত্যিকারের SMS পাঠানোর অংশ
                if (!string.IsNullOrEmpty(apiKey) && apiKey != "YOUR_SMS_GATEWAY_API_KEY")
                {
                    string url = $"https://api.greenweb.com.bd/api.php?token={apiKey}&to={receiverNumber}&message={Uri.EscapeDataString(message)}";
                    using (var httpClient = new HttpClient())
                    {
                        await httpClient.GetAsync(url);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorMessage = $"SMS Error: {ex.Message}";
                Debug.WriteLine(errorMessage);
                Console.WriteLine(errorMessage);
            }
        }
    }
}